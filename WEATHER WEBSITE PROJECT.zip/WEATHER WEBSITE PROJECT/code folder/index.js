const express = require('express');
const app = express();
const path = require('path');
const hbs = require('hbs');
const bodyParser = require('body-parser');
const https = require('https');

app.use(bodyParser.urlencoded({ extended: true }));

let templatePath = path.join(__dirname, '../templates/views');
let partialPath = path.join(__dirname, '../templates/partials');

const imagesPath = path.join(__dirname, '../templates/images');
const cssPath = path.join(__dirname, '../templates/css');

app.use('/images', express.static(imagesPath));   // you should have to write this otherwise images will not get included.
app.use('/css', express.static(cssPath));

console.log(imagesPath);

app.set('view engine', 'hbs');
app.set('views', templatePath);

hbs.registerPartials(partialPath);

app.get('/', (req, res) => {
   res.render('home');
});

app.get('/home', (req, res) => {
   res.render('home');
});

app.get('/about', (req, res) => {
    res.render('about');
});

app.get('/contact', (req, res) => {
    res.render('contact');
});

app.get('/weather', (req, res) => {
    res.render('weather');
});

app.get('/*', (req, res) => {
    res.render('404 error');
});

app.post('/weather', (req, res) => {
    let search = req.body.search;
    let statusCode;
    let temp;
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${search}&appid=839a90972389027b2fd8b642bd3be35f&units=metric`;
    let ApiData = '';
    
    https.get(url, (response) => {
        statusCode = response.statusCode;
        console.log(statusCode);
      
        response.on('data', (chunk) => {
            ApiData = ApiData + chunk;
        });

        response.on('end', () => {
            ApiData = JSON.parse(ApiData);
            if(response.statusCode==200)
            {
                 temp = ApiData.main.temp;
            console.log(temp);
            }

            if (statusCode != 200) {

                res.render('weather', {
                    city: 'N/A',
                    temp: 'N/A'
                });
                
            } else {
                res.render('weather', {
                    city: search,
                    temp: temp
                });
            }
        });
    });
});

app.listen(4000, () => {
    console.log('Server is running on port 4000');
});
